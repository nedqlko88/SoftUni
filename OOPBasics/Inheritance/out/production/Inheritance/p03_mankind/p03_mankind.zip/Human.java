package p03_mankind;

public class Human {
    private String firstName;
    private String lastName;

    public Human(String firstName, String lastName) {
        this.setFirstName(firstName);
        this.setLastName(lastName);
    }

    public String getFirstName() {
        return this.firstName;
    }

    private void setFirstName(String firstName) {
        if (this.validateName(4, firstName)) {
                this.firstName = firstName;
        }
    }

    public String getLastName() {
        return this.lastName;
    }

    private void setLastName(String lastName) {
        if (this.validateName(3, lastName)) {
            this.lastName = lastName;
        }
    }

    private boolean validateName(int countOfSymbols, String name) {
        if (name.length() < countOfSymbols) {
            throw new IllegalArgumentException(String.format("Expected length at least %d symbols!Argument: %s", countOfSymbols, name));
        }
        if (Character.isLowerCase(name.charAt(0))) {
            throw new IllegalArgumentException(String.format("Expected upper case letter!Argument: %s", name));
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder human = new StringBuilder();
        human.append("First Name: ").append(this.getFirstName())
                .append(System.lineSeparator())
                .append("Last Name: ").append(this.getLastName())
                .append(System.lineSeparator());
        return human.toString();
    }
}
