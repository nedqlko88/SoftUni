package p08_military_elit.contracts;

public interface Commando extends SpecialisedSoldier{
}
