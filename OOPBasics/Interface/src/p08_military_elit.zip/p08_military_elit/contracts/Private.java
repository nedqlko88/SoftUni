package p08_military_elit.contracts;

public interface Private extends Soldier{
}
