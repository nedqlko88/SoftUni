package p08_military_elit.contracts;

public interface LeutenantGeneral extends Private{
}
