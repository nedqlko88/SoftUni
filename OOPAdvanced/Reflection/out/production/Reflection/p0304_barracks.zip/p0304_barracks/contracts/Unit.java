package p0304_barracks.contracts;

import p0304_barracks.contracts.Attacker;
import p0304_barracks.contracts.Destroyable;

public interface Unit extends Destroyable, Attacker {
}
