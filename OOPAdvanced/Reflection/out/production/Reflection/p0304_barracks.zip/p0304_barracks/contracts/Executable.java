package p0304_barracks.contracts;

public interface Executable {

	String execute();

}
