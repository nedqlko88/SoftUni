package p0304_barracks.contracts;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
