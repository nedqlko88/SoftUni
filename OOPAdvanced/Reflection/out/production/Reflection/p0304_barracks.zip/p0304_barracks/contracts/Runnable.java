package p0304_barracks.contracts;

public interface Runnable {
	void run();
}
