package p0304_barracks.core.commands;


import p0304_barracks.contracts.Repository;
import p0304_barracks.contracts.Unit;
import p0304_barracks.contracts.UnitFactory;
import p0304_barracks.data.UnitRepository;

public class AddCommand extends BaseCommand {

    public AddCommand(String[] data, Repository repository, UnitFactory unitFactory) {
        super(data, repository, unitFactory);
    }

    @Override
    public String execute() {
        String unitType = super.getData()[1];
        Unit unitToAdd = super.getUnitFactory().createUnit(unitType);

        super.getRepository().addUnit(unitToAdd);

        return unitType + " added!";

    }
}
