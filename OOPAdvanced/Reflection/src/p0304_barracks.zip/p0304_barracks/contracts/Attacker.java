package p0304_barracks.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
