package hell.entities.miscellaneous;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HeroInventoryTest {

    @BeforeEach
    void setUp() {
    }

    @Test
    void getTotalStrengthBonus() {
    }

    @Test
    void getTotalAgilityBonus() {
    }

    @Test
    void getTotalIntelligenceBonus() {
    }

    @Test
    void getTotalHitPointsBonus() {
    }

    @Test
    void getTotalDamageBonus() {
    }

    @Test
    void addCommonItem() {
    }

    @Test
    void addRecipeItem() {
    }
}