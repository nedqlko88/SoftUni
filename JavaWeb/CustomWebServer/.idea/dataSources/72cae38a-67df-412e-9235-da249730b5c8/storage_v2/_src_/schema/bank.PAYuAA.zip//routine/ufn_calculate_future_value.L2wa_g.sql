create function ufn_calculate_future_value(sum double, yearly_interest_rate double, years int) returns double
BEGIN
	DECLARE result DOUBLE;
    SET result := sum * POWER((1 + yearly_interest_rate),years);
    RETURN result;
END;

