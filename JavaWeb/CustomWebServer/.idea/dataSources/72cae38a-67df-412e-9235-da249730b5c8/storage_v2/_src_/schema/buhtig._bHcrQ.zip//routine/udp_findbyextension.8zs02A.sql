create procedure udp_findbyextension(IN extension varchar(100))
BEGIN
	SELECT id, name AS `caption`, CONCAT(size, 'KB') AS `user`
    FROM files
    WHERE name LIKE CONCAT('%.',extension);
END;

