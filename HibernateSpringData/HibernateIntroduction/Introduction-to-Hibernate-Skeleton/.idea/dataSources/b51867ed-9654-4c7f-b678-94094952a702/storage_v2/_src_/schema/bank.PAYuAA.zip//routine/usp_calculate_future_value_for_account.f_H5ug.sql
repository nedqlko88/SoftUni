create procedure usp_calculate_future_value_for_account(IN account_id int, IN interest_rate double)
BEGIN
	SELECT a.id, ah.first_name, ah.last_name, a.balance AS `current_balance`, ROUND(ufn_calculate_future_value(a.balance, interest_rate, 5),4) AS `balance_in_5_years`
	FROM account_holders AS ah
	JOIN accounts AS a
	ON a.account_holder_id = ah.id
    HAVING a.id = account_id;
END;

