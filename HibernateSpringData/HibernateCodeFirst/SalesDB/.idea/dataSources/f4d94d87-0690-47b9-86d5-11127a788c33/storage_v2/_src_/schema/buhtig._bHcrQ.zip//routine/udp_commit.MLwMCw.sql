create procedure udp_commit(IN username varchar(30), IN password varchar(30), IN message varchar(255), IN issue_id int)
BEGIN
	DECLARE repository_id INT;
    DECLARE user_id INT;

      
	IF 1 <> (SELECT COUNT(*) FROM users WHERE users.username = username)
    THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'No such user!';
	END IF;
	
	IF 1 <> (SELECT COUNT(*) FROM users WHERE users.username = username AND users.password = password)
    THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'Password is incorrect!';
	END IF;
    
	IF 1 <> (SELECT COUNT(*) FROM issues WHERE issues.id = issue_id)
    THEN
		SIGNAL SQLSTATE '45000'
		SET MESSAGE_TEXT = 'The issue does not exist!';
	END IF;

	SET user_id := (
		SELECT u.id
        FROM users u
        WHERE u.username = username
	);
	SET repository_id := (
		SELECT i.repository_id
        FROM issues i
        WHERE i.id = issue_id
	);
    
    INSERT INTO commits (repository_id, contributor_id, issue_id, message)
    VALUES (repository_id, user_id, issue_id, message);
    
END;

