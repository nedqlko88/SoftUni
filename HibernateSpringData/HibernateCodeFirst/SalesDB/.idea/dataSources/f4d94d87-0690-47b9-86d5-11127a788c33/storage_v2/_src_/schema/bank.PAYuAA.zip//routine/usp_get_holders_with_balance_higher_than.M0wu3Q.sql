create procedure usp_get_holders_with_balance_higher_than(IN mount double)
BEGIN
	SELECT ah.first_name,ah.last_name
    FROM account_holders AS ah
    JOIN accounts AS a
    ON ah.id = a.account_holder_id
    GROUP BY a.account_holder_id
    HAVING SUM(a.balance) > mount
    ORDER BY ah.first_name, ah.last_name, a.id;
END;

